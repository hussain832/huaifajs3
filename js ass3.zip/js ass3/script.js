function runScripts() {
    // Question 1: Check city
    var city = "Karachi";
    if (city === "Karachi") {
        console.log("The City OF Lights");
    }

    // Question 2: Prompt for 'z'
    let x = 5, y = 5;
    if (x === y) {
        let z = prompt("Enter the value of z:");
        let anotherVar = z;
    }

    // Question 3: Check ZipCode
    var ZipCode = "10010";
    if (ZipCode === "10010") {
        alert("Karachi");
    } else {
        alert("Please write correct city");
    }

    // Question 4: Change variable value
    var num = 1;
    if (num === 1) {
        num = 5;
    }

    // Comparison Operators
    let a = 5;
    let b = 10;
    if (a !== b) {console.log("Not equal"); }
    if (a >= b) { console.log("a is greater or equal to b"); }

    // Marksheet Program
    let marks = prompt("Enter your marks out of 100:");
    let percentage = (marks / 100) * 100;

    if (percentage >= 80) {
        alert("Grade: A+");
    } else if (percentage >= 70) {
        alert("Grade: A");
    } else if (percentage >= 60) {
        alert("Grade: B");
    } else if (percentage >= 50) {
        alert("Grade: C");
    } else {
        alert("Fail");
    }

    // Name check
    let firstName = prompt("Enter your first name:");
    if (firstName !== "Ali") {
        alert("No match");
    }

    // Password validation
    let password = prompt("Enter your password:");
    if (password) {
        if (password.length <= 5) {
            alert("Password must be greater than 5");
        } else {
            alert("OK");
        }
    } else {
        alert("Please enter your password");
    }

    // Check character type
    let char = prompt("Enter a character:");
    let ascii = char.charCodeAt(0);

    if (ascii >= 65 && ascii <= 90) {
        alert("Uppercase Letter");
    } else if (ascii >= 97 && ascii <= 122) {
        alert("Lowercase Letter");
    } else if (ascii >= 48 && ascii <= 57) {
        alert("Number");
    }

    // Find larger number
    let num1 = prompt("Enter first number:");
    let num2 = prompt("Enter second number:");
    if (num1 > num2) {
        alert(num1 + " is larger");
    } else if (num2 > num1) {
        alert(num2 + " is larger");
    } else {
        alert("Both numbers are equal");
    }

    // Positive, negative, or zero
    let numCheck = prompt("Enter a number:");
    if (numCheck > 0) {
        alert("Positive number");
    } else if (numCheck < 0) {
        alert("Negative number");
    } else {
        alert("Zero");
    }

    // Check if input is a vowel
    let vowelCheck = prompt("Enter a single character:").toLowerCase();
    if ("aeiou".includes(vowelCheck)) {
        alert("It is a vowel");
    } else {
        alert("Not a vowel");
    }

    // Guess game
    let secretNumber = 7;
    let guess = parseInt(prompt("Guess a number (1-10):"));
    if (guess === secretNumber) {
        alert("Bingo! Correct answer");
    } else if (guess + 1 === secretNumber) {
        alert("Close enough to the correct answer");
    } else {
        alert("Wrong guess");
    }

    // Check divisibility by 3
    let number = prompt("Enter a number:");
    if (number % 3 === 0) {
        alert("Number is divisible by 3");
    }

    // Check even or odd
    if (number % 2 === 0) {
        alert("Even number");
    } else {
        alert("Odd number");
    }

    // Temperature conditions
    let temp = prompt("Enter temperature:");
    if (temp > 40) {
        alert("It is too hot outside.");
    } else if (temp > 30) {
        alert("The Weather today is Normal.");
    } else if (temp > 20) {
        alert("Today's Weather is cool.");
    } else if (temp > 10) {
        alert("OMG! Today's weather is so Cool.");
    }

    // Simple Calculator
    let numA = parseFloat(prompt("Enter first number:"));
    let numB = parseFloat(prompt("Enter second number:"));
    let operation = prompt("Enter operation (+, -, *, /, %):");

    if (operation === "+") {
        alert("Result: " + (numA + numB));
    } else if (operation === "-") {
        alert("Result: " + (numA - numB));
    } else if (operation === "*") {
        alert("Result: " + (numA * numB));
    } else if (operation === "/") {
        alert("Result: " + (numA / numB));
    } else if (operation === "%") {
        alert("Result: " + (numA % numB));
    } else {
        alert("Invalid Operation");
    }
}
